package Main.service;

import Main.dto.request.ChiNhanhDTO;
import Main.dto.request.KhungGioCoDinhDTO;
import Main.dto.request.SanDTO;
import Main.dto.request.SanInfoDTO;
import Main.entity.San;
import Main.repository.ChiNhanhRepository;
import Main.repository.DatsanRepository;
import Main.repository.NgayRepository;
import Main.repository.SanRepository;
import Main.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private SanRepository sanRepository;
    @Autowired
    private ChiNhanhRepository chiNhanhRepository;
    @Autowired
    private DatsanRepository datsanRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private NgayRepository ngayRepository;

    @Override
    public San filterSanByTen(String tenSan) {
        return sanRepository.findByTenSan(tenSan)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sân: " + tenSan));
    }

    @Override
    public List<SanInfoDTO> filterSanByKhuVuc(Long chiNhanhId) {
        return sanRepository.findByChiNhanhId(chiNhanhId).stream()
                .map(san -> new SanInfoDTO(
                        san.getId(),
                        san.getTenSan(),
                        san.getLoaiSan(),
                        san.getChiNhanh().getTenChiNhanh(),
                        san.getGiaSan()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public List<SanInfoDTO> getAllSan() {
        return sanRepository.findAll().stream()
                .map(san -> new SanInfoDTO(
                        san.getId(),
                        san.getTenSan(),
                        san.getLoaiSan(),
                        san.getChiNhanh().getTenChiNhanh(),
                        san.getGiaSan()
                ))
                .collect(Collectors.toList());
    }

    @Override
    public List<ChiNhanhDTO> getAllChiNhanh() {
        return chiNhanhRepository.findAll().stream()
                .map(cn -> new ChiNhanhDTO(cn.getId(), cn.getTenChiNhanh()))
                .collect(Collectors.toList());
    }

    @Override
    public List<San> filterSanByLoaiSan(String loaiSan) {
        return sanRepository.findByLoaiSan(loaiSan);
    }

    @Override
    public SanDTO getSanInfoById(Long id) {
        San san = sanRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sân với ID: " + id));

        List<KhungGioCoDinhDTO> khungGioDtos = san.getKhungGioCoDinhs().stream()
                .map(kg -> new KhungGioCoDinhDTO(
                        kg.getId(),
                        kg.getThoiGianBatDau() + "-" + kg.getThoiGianKetThuc(),
                        kg.isDaDat() ? "DA_DAT" : "CHUA_DAT"
                ))
                .collect(Collectors.toList());

        // Gọi đúng constructor SanDTO với 6 tham số: id, tenSan, loaiSan, diaChi, giaSan, khungGioDtos
        return new SanDTO(
                san.getId(),
                san.getTenSan(),
                san.getLoaiSan(),
                san.getChiNhanh().getDiaChi(),
                san.getGiaSan(),
                khungGioDtos
        );
    }
}
