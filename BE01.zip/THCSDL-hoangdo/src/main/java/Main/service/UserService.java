package Main.service;

import Main.dto.request.ChiNhanhDTO;
import Main.dto.request.SanDTO;
import Main.dto.request.SanInfoDTO;
import Main.entity.San;

import java.util.List;

public interface UserService {
    // Tìm sân theo tên
    San filterSanByTen(String tenSan);

    // Tìm sân theo chi nhánh
    List<SanInfoDTO> filterSanByKhuVuc(Long chiNhanhId);

    // Tìm tất cả sân
    List<SanInfoDTO> getAllSan();

    // Tìm tất cả chi nhánh
    List<ChiNhanhDTO> getAllChiNhanh();

    // Tìm sân theo loại (nếu cần)
    List<San> filterSanByLoaiSan(String loaiSan);

    // Lấy thông tin chi tiết sân, bao gồm cả khung giờ
    SanDTO getSanInfoById(Long id);
}
