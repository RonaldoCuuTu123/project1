package Main.dto.request;

import java.util.List;

public class SanDTO {
    private Long id;
    private String tenSan;
    private String loaiSan;
    private String diaChi;
    private Long giaSan;
    private List<KhungGioCoDinhDTO> khungGioCoDinhs;

    public SanDTO() {}

    // Full-args constructor
    public SanDTO(Long id,
                  String tenSan,
                  String loaiSan,
                  String diaChi,
                  Long giaSan,
                  List<KhungGioCoDinhDTO> khungGioCoDinhs) {
        this.id = id;
        this.tenSan = tenSan;
        this.loaiSan = loaiSan;
        this.diaChi = diaChi;
        this.giaSan = giaSan;
        this.khungGioCoDinhs = khungGioCoDinhs;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTenSan() { return tenSan; }
    public void setTenSan(String tenSan) { this.tenSan = tenSan; }

    public String getLoaiSan() { return loaiSan; }
    public void setLoaiSan(String loaiSan) { this.loaiSan = loaiSan; }

    public String getDiaChi() { return diaChi; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }

    public Long getGiaSan() { return giaSan; }
    public void setGiaSan(Long giaSan) { this.giaSan = giaSan; }

    public List<KhungGioCoDinhDTO> getKhungGioCoDinhs() { return khungGioCoDinhs; }
    public void setKhungGioCoDinhs(List<KhungGioCoDinhDTO> khungGioCoDinhs) { this.khungGioCoDinhs = khungGioCoDinhs; }
}
