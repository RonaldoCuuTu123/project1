package Main.dto.request;

public class KhungGioCoDinhDTO {
    private Long id;
    private String khungGio;
    private String trangThai;
    public KhungGioCoDinhDTO() {}
    public KhungGioCoDinhDTO(Long id, String khungGio, String trangThai) {
        this.id = id;
        this.khungGio = khungGio;
        this.trangThai = trangThai;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getKhungGio() { return khungGio; }
    public void setKhungGio(String khungGio) { this.khungGio = khungGio; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
}
