package Main.dto.request;

public class SanInfoDTO {
    private Long id;
    private String tenSan;
    private String loaiSan;
    private String tenChiNhanh;
    private Long giaSan;

    public SanInfoDTO() {}

    // Constructor có đủ 5 tham số
    public SanInfoDTO(Long id, String tenSan, String loaiSan, String tenChiNhanh, Long giaSan) {
        this.id = id;
        this.tenSan = tenSan;
        this.loaiSan = loaiSan;
        this.tenChiNhanh = tenChiNhanh;
        this.giaSan = giaSan;
    }

    // Các getter / setter
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTenSan() { return tenSan; }
    public void setTenSan(String tenSan) { this.tenSan = tenSan; }

    public String getLoaiSan() { return loaiSan; }
    public void setLoaiSan(String loaiSan) { this.loaiSan = loaiSan; }

    public String getTenChiNhanh() { return tenChiNhanh; }
    public void setTenChiNhanh(String tenChiNhanh) { this.tenChiNhanh = tenChiNhanh; }

    public Long getGiaSan() { return giaSan; }
    public void setGiaSan(Long giaSan) { this.giaSan = giaSan; }
}
