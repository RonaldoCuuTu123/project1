package Main.controller;

import Main.dto.request.LoginRequest;
import Main.dto.request.SignupRequest;
import Main.entity.User;
import Main.repository.UserRepository;
import Main.security.JwtTokenProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        logger.info("=== [LOGIN] === Attempting to authenticate user with email: {}", loginRequest.getEmail());

        try {
            // 1. Tìm user trong database
            User user = userRepository.findByEmail(loginRequest.getEmail())
                    .orElseThrow(() -> {
                        logger.error("User not found with email: {}", loginRequest.getEmail());
                        return new RuntimeException("User not found");
                    });

            // 2. Log user info lấy ra từ DB
            logger.info("[LOGIN] User found: id={}, email={}, role={}, password(hash)={}",
                    user.getId(), user.getEmail(), user.getVaiTro(), user.getMatKhau());

            // 3. Log password input & hash
            logger.info("[LOGIN] Password nhập từ FE: '{}'", loginRequest.getPassword());
            logger.info("[LOGIN] Hash password từ DB: '{}'", user.getMatKhau());

            // 4. So sánh password
            boolean isMatch = passwordEncoder.matches(loginRequest.getPassword(), user.getMatKhau());
            logger.info("[LOGIN] PasswordEncoder.matches result: {}", isMatch);

            if (!isMatch) {
                logger.error("[LOGIN] Password does NOT match for user: {}", loginRequest.getEmail());
                return ResponseEntity.status(401).body("Invalid password");
            }

            // 5. Xác thực với AuthenticationManager
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getEmail(),
                            loginRequest.getPassword()));
            logger.info("[LOGIN] Authentication success: {}", authentication.isAuthenticated());

            // 6. Tạo token và trả về response
            String jwt = tokenProvider.generateToken(authentication);
            logger.info("[LOGIN] Generated JWT token: {}", jwt);

            Map<String, Object> response = new HashMap<>();
response.put("token", jwt);
response.put("user", Map.of(
    "id", user.getId(),
    "email", user.getEmail(),
    "role", user.getVaiTro()
));

return ResponseEntity.ok(response);


        } catch (Exception e) {
            logger.error("[LOGIN] Authentication failed for {}: {}", loginRequest.getEmail(), e.getMessage(), e);
            return ResponseEntity.status(401).body("Authentication failed: " + e.getMessage());
        }
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody SignupRequest signupRequest) {
        if (userRepository.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Email đã được sử dụng!");
        }

        User user = new User();
        user.setHoTen(signupRequest.getHoTen());
        user.setEmail(signupRequest.getEmail());
        user.setMatKhau(passwordEncoder.encode(signupRequest.getPassword()));
        user.setSoDienThoai(signupRequest.getSoDienThoai());
        user.setVaiTro("USER"); // Luôn set vai trò là USER

        userRepository.save(user);

        return ResponseEntity.ok("Đăng ký thành công!");
    }

    @PostMapping("/create-admin")
    public ResponseEntity<?> createAdmin(@RequestBody SignupRequest signupRequest) {
        if (userRepository.existsByEmail(signupRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Email đã được sử dụng!");
        }

        User admin = new User();
        admin.setHoTen(signupRequest.getHoTen());
        admin.setEmail(signupRequest.getEmail());
        admin.setMatKhau(passwordEncoder.encode(signupRequest.getPassword()));
        admin.setSoDienThoai(signupRequest.getSoDienThoai());
        admin.setVaiTro("ADMIN");

        userRepository.save(admin);
        logger.debug("Created admin user: email={}, role={}", admin.getEmail(), admin.getVaiTro());

        return ResponseEntity.ok("Tạo tài khoản admin thành công!");
    }
}