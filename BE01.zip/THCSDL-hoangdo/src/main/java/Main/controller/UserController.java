package Main.controller;

import Main.dto.request.ChiNhanhDTO;
import Main.dto.request.DatSanRequest;
import Main.dto.request.SanDTO;
import Main.entity.San;
import Main.entity.User;
import Main.repository.UserRepository;
import Main.service.DatSanService;
import Main.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private DatSanService datSanService;

    @Autowired
    private UserRepository userRepository;

    // 1) Lấy tất cả sân dưới dạng SanInfoDTO
    @GetMapping("/all")
    public List<Main.dto.request.SanInfoDTO> getAllSan() {
        return userService.getAllSan();
    }

    // 2) Lấy tất cả chi nhánh
    @GetMapping("/chiNhanh")
    public List<ChiNhanhDTO> getAllChiNhanh() {
        return userService.getAllChiNhanh();
    }

    // 3) Lấy sân theo khu vực
    @GetMapping("/khuVuc")
    public List<Main.dto.request.SanInfoDTO> getKhuVuc(@RequestParam Long chiNhanhId) {
        return userService.filterSanByKhuVuc(chiNhanhId);
    }

    // 4) Lấy sân theo tên — trả về entity San
    @GetMapping("/ten")
    public San getSanTheoTen(@RequestParam String ten) {
        return userService.filterSanByTen(ten);
    }

    // 5) Lấy chi tiết sân theo ID
    @GetMapping("/{id}")
    public SanDTO getSan(@PathVariable Long id) {
        return userService.getSanInfoById(id);
    }

    // 6) Đặt sân
    @PostMapping("/datSan")
public ResponseEntity<?> datSan(@RequestBody DatSanRequest req, Authentication auth) {
    try {
        String result = datSanService.datSan(req.getSanId(), req.getUserId(), req.getKhungGioCoDinhId(), req.getNgay());
        return ResponseEntity.ok(result);
    } catch (RuntimeException e) {
        if (e.getMessage().contains("Sân đã được đặt")) {
            return ResponseEntity.status(409).body("Sân đã được đặt!");
        }
        return ResponseEntity.status(400).body(e.getMessage());
    }
}


    // 7) Lấy tất cả user role=USER nếu cần
    @GetMapping("/role/user")
    public ResponseEntity<?> getAllUsers() {
        try {
            List<User> users = userRepository.findByVaiTro("USER");
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            return ResponseEntity
              .badRequest()
              .body("Lỗi khi lấy danh sách user: " + e.getMessage());
        }
    }
}
