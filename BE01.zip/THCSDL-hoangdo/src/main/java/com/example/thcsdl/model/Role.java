package com.example.thcsdl.model;

public enum Role {
    USER,
    ADMIN
} 